﻿using System.Collections.Generic;
using System.Linq;

namespace NPL.Test_1.Management
{
    public class HelicopterManagament
    {
        Airports airports = new Airports();
        public void Add(Helicopter helicopter)
        {
            if (helicopter != null)
            {
                airports.listCopters.Add(helicopter);
            }
        }

        public List<Helicopter> DisplayAllFixedWingAirplain()
        {
            return (from item in airports.listCopters
                    select item).ToList();
        }
    }
}
