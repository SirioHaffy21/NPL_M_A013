﻿using System.Collections.Generic;
using System.Linq;

namespace NPL.Test_1.Management
{
    public class FixedWingManagement
    {
        Airports airports = new Airports();
        public void Add(Fixedwing fixedwing)
        {
            fixedwing = new Fixedwing();

            if (fixedwing != null)
            {
                airports.listWings.Add(fixedwing);
            }
        }

        public List<Fixedwing> DisplayAllFixedWingAirplain()
        {
            return (from item in airports.listWings
                    select item).ToList();
        }
    }
}
