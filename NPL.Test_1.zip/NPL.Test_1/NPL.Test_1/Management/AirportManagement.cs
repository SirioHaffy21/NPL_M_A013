﻿using System.Collections.Generic;
using System.Linq;


namespace NPL.Test_1.Management
{

    public class AirportManagement
    {
        public static Airports airports = new Airports();

        public static List<Airports> listAirports = new List<Airports>();

        public void Add(Airports airports)
        {
            if (airports != null)
            {
                listAirports.Add(airports);
            }
        }

        public List<Airports> DisplayAllAndSortID()
        {
            return (from item in listAirports
                    orderby item.ID ascending
                    select item).ToList();
        }

        public List<Airports> DisplayStatusByID(string id)
        {
            return (from item in listAirports
                    where item.ID == id
                    select item).ToList();
        }

    }
}
