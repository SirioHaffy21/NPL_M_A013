﻿using System.Collections.Generic;

namespace NPL.Test_1
{
    public class Airports
    {
        public Airports()
        {

        }

        public Airports(string iD, string name, bool status, double runwaySize, double maxFixedParkingPlace, double maxRotatedParkingPlace)
        {
            ID = iD;
            Name = name;
            Status = status;
            RunwaySize = runwaySize;
            MaxFixedParkingPlace = maxFixedParkingPlace;
            MaxRotatedParkingPlace = maxRotatedParkingPlace;
        }

        public string ID { get; set; }

        public string Name { get; set; }

        public bool Status { get; set; }

        public double RunwaySize { get; set; }

        public double MaxFixedParkingPlace { get; set; }

        public double MaxRotatedParkingPlace { get; set; }

        public List<Fixedwing> listWings { get; set; } = new List<Fixedwing>();

        public List<Helicopter> listCopters { get; set; } = new List<Helicopter>();
    }
}
