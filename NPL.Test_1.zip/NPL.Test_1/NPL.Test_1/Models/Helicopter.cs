﻿namespace NPL.Test_1
{
    public class Helicopter : Airplane
    {
        public Helicopter()
        {

        }

        public Helicopter(string iD, string model, double cruiseSpeed, 
            double emptyWeight, double maxTakeOffWeight, int range) 
                    : base(iD, model, cruiseSpeed, emptyWeight, maxTakeOffWeight)
        {
            Range = range;
        }

        public int Range { get; set; }
    }
}
