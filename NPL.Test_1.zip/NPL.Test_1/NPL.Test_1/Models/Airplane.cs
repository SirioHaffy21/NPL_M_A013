﻿namespace NPL.Test_1
{
    public class Airplane
    {
        public Airplane()
        {

        }

        public Airplane(string iD, string model, double cruiseSpeed, double emptyWeight, double maxTakeOffWeight)
        {
            ID = iD;
            Model = model;
            CruiseSpeed = cruiseSpeed;
            EmptyWeight = emptyWeight;
            MaxTakeOffWeight = maxTakeOffWeight;
        }


        public string ID { get; set; }

        public string Model { get; set; }

        public double CruiseSpeed { get; set; }

        public double EmptyWeight { get; set; }

        public double MaxTakeOffWeight { get; set; }
    }
}
