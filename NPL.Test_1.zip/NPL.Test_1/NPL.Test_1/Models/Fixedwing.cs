﻿namespace NPL.Test_1
{
    public class Fixedwing : Airplane
    {
        public Fixedwing()
        {

        }

        public Fixedwing(string iD, string model, double cruiseSpeed, double emptyWeight, 
                         double maxTakeOffWeight, int planeType, double minNeedRunwaySize) 
            : base(iD, model, cruiseSpeed, emptyWeight, maxTakeOffWeight)
        {
            PlaneType = planeType;
            MinNeedRunwaySize = minNeedRunwaySize;
        }

        public int PlaneType { get; set; }

        public double MinNeedRunwaySize { get; set; }
    }
}
