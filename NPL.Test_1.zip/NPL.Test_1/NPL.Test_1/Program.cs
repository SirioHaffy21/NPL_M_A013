﻿using NPL.Test_1.Management;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace NPL.Test_1
{
    internal class Program
    {

        public static AirportManagement airport = new AirportManagement();
        public static FixedWingManagement fixedWings = new FixedWingManagement();
        public static HelicopterManagament heliCopter = new HelicopterManagament();

        private static void Main(string[] args)
        {
            MainMenu();

            Console.ReadKey();
        }

        private static void MainMenu()
        {
            int selectMenu = 0;
            try
            {
                do
                {
                    Console.WriteLine("====== Select fearture =======");
                    Console.WriteLine("1. Input to Airport: ");
                    Console.WriteLine("2. Airport Management: ");
                    Console.WriteLine("3. Fixed wing airplane management: ");
                    Console.WriteLine("4. Helicopter management group: ");
                    Console.WriteLine("5. Close program: ");

                    Console.Write("Select feature of programs: ");
                    selectMenu = int.Parse(Console.ReadLine());

                    switch (selectMenu)
                    {
                        case 1:

                            InputAirport();
                            break;

                        case 2:

                            AirportManagement();
                            break;

                        case 3:

                            FixedWingAirplaneManagement();
                            break;

                        case 4:

                            HelicopterManagement();
                            break;

                        case 5:

                            Environment.Exit(0);
                            break;
                    }

                } while (selectMenu != 1 || selectMenu != 2 || selectMenu != 3 || selectMenu != 4 || selectMenu != 5);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Input again. Because failed standard of format. ");
                Console.WriteLine(ex.Message);
            }

        }

        private static void HelicopterManagement()
        {
            List<Helicopter> helicopters = heliCopter.DisplayAllFixedWingAirplain();

            foreach (var item in helicopters)
            {
                Console.WriteLine("{0, 20} {1, 20}", item.ID, item.Model);
            }
        }

        private static void FixedWingAirplaneManagement()
        {
            List<Fixedwing> fixedwings = fixedWings.DisplayAllFixedWingAirplain();

            foreach (var item in fixedwings)
            {
                Console.WriteLine("{0, 20} {1, 20}", item.ID, item.Model);
            }
        }

        private static void AirportManagement()
        {
            int selectAirport = 0;
            do
            {
                Console.WriteLine("------ Select feature ------");
                Console.WriteLine("1. Display all airport information and sort by airportID.");
                Console.WriteLine("2. Display the status airport information and selected by airportID.");
                Console.WriteLine("3. Close airport management. ");
                selectAirport = int.Parse(Console.ReadLine());

                switch (selectAirport)
                {
                    case 1:
                        DisplayAllAirportInformationAndSortByAirportID();
                        break;

                    case 2:
                        DisplayStatusAirportInformationAndSelectedByAirportID();
                        break;

                    case 3:
                        MainMenu();
                        break;
                }

            } while (true);

        }

        private static void DisplayStatusAirportInformationAndSelectedByAirportID()
        {
            Console.Write("Input ID of airplain: ");
            string airplainID = Console.ReadLine();


            List<Airports> listAirport = airport.DisplayStatusByID(airplainID);

            foreach (var item in listAirport)
            {
                Console.WriteLine("{0, 20}{1, 20}", item.Name, item.Status);
            }


        }

        private static void DisplayAllAirportInformationAndSortByAirportID()
        {
            List<Airports> listAirport = airport.DisplayAllAndSortID();

            foreach (var item in listAirport)
            {
                Console.WriteLine("{0, 20}{1, 20}{2, 20}{3, 20}{4, 20}{5, 20}", item.ID, item.Name, item.Status,
                    item.RunwaySize, item.MaxFixedParkingPlace, item.MaxRotatedParkingPlace);
            }
        }

        private static void InputAirport()
        {
            int selectMenuInput = 0;
            try
            {
                do
                {
                    Console.WriteLine("---- Select feature input ----");
                    Console.WriteLine("1. Input to Airport management. ");
                    Console.WriteLine("2. Input to fixed Wings. ");
                    Console.WriteLine("3. Input to Helicopter. ");
                    Console.WriteLine("4. Close menu import. ");

                    Console.Write("Select feature of input airport menu: ");
                    selectMenuInput = int.Parse(Console.ReadLine());

                    switch (selectMenuInput)
                    {
                        case 1:
                            InputAirportInformations();
                            break;

                        case 2:
                            InputFixedWings();
                            break;

                        case 3:
                            InputHelicopter();
                            break;

                        case 4:

                            MainMenu();
                            break;
                    }

                } while (selectMenuInput != 1 || selectMenuInput != 2 || selectMenuInput != 3 || selectMenuInput != 4);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Input again. Because failed standard of format. ");
                Console.WriteLine(ex.Message);
            }

        }

        private static void InputAirportInformations()
        {
            string patternID = @"^AP+[0-9]{5}$";
            string iDAirport = string.Empty;
            bool checkIDAirport = Regex.IsMatch(iDAirport, patternID);

            while (checkIDAirport == false)
            {

                Console.Write("Input Id of airport: ");
                iDAirport = Console.ReadLine();

                if (checkIDAirport == false)
                {
                    break;
                }

            }


            Console.Write("Input Name of airport: ");
            string nameAirport = Console.ReadLine();

            bool status;
            Console.Write("Input status of airport: ");
            while (true)
            {
                if (bool.TryParse(Console.ReadLine(), out status))
                {
                    break;
                }
            }

            GetStatus(status);

            double sizeOfRunway = 0;
            Console.Write("Input sixe of runway of airport: ");
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out sizeOfRunway))
                {
                    break;
                }
            }

            double maxFixedParking = 0;
            Console.Write("Input Max Fixed Parking Place of airport: ");
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out maxFixedParking))
                {
                    break;
                }
            }

            double maxRotatedParking = 0;
            Console.Write("Input Max Rotated Parking Place of airport: ");
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out maxRotatedParking))
                {
                    break;
                }
            }

            Airports airports = new Airports(iDAirport, nameAirport, status,
                sizeOfRunway, maxFixedParking, maxRotatedParking);

            airport.Add(airports);
        }

        private static void InputHelicopter()
        {
            string patternID = @"^RW+[0-9]{5}$";
            string iDHelicopter = string.Empty;
            bool checkIDAirport = Regex.IsMatch(iDHelicopter, patternID);

            while (checkIDAirport == false)
            {
                Console.Write("Input Id of Helicopter: ");
                iDHelicopter = Console.ReadLine();

                if (checkIDAirport == false)
                {
                    break;
                }
            }

            Console.Write("Input model of helicopter: ");
            string modelHeli = Console.ReadLine();
            while (modelHeli.Length > 40 && modelHeli.Length <= 0)
            {

                if (modelHeli.Length <= 40 && modelHeli.Length > 0)
                {
                    break;
                }
            }

            double cruiseSpeed = 0;
            Console.Write("Input cruise of speed: ");
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out cruiseSpeed))
                {
                    break;
                }
            }

            double emptyWeight = 0;
            Console.Write("Input weight of empty: ");
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out emptyWeight) && emptyWeight <= 1.5)
                {
                    break;
                }
            }

            double maxTakeOffWeight = 0;
            Console.Write("Input max weight of take off: ");
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out maxTakeOffWeight))
                {
                    break;
                }
            }

            int range = 0;
            Console.Write("Input range: ");
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out range) && range <= 20)
                {
                    break;
                }
            }

            Helicopter helicopter = new Helicopter(iDHelicopter, modelHeli,
                cruiseSpeed, emptyWeight, maxTakeOffWeight, range);
            heliCopter.Add(helicopter);
        }

        private static void InputFixedWings()
        {
            string patternID = @"^FW+[0-9]{5}$";
            string iDFixedWings = string.Empty;
            bool checkIDAirport = Regex.IsMatch(iDFixedWings, patternID);

            Console.Write("Input Id of fixed wings: ");
            iDFixedWings = Console.ReadLine();

            while (checkIDAirport == false)
            {

                if (checkIDAirport == false)
                {
                    break;
                }

            }

            Console.Write("Input model of fixed wings: ");
            string modelWings = Console.ReadLine();

            while (modelWings.Length > 40 && modelWings.Length <= 0)
            {

                if (modelWings.Length <= 40 && modelWings.Length > 0)
                {
                    break;
                }
            }

            double cruiseSpeed = 0;
            Console.Write("Input cruise of speed: ");
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out cruiseSpeed))
                {
                    break;
                }
            }

            double emptyWeight = 0;
            Console.Write("Input weight of empty: ");
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out emptyWeight) && emptyWeight <= 1.5)
                {
                    break;
                }
            }

            double maxTakeOffWeight = 0;
            Console.Write("Input max weight of take off: ");
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out maxTakeOffWeight))
                {
                    break;
                }
            }

            int typeOfPlans = 0;
            Console.Write("Input type of plain: ");
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out typeOfPlans) && (typeOfPlans == 0 || typeOfPlans == 1))
                {
                    break;
                }
            }

            double minNeedRunwaySize = 0;
            Console.Write("Input min size of runway: ");
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out minNeedRunwaySize))
                {
                    break;
                }
            }

            Fixedwing fixedwing = new Fixedwing(iDFixedWings, modelWings, cruiseSpeed,
                emptyWeight, maxTakeOffWeight, typeOfPlans, minNeedRunwaySize);

            fixedWings.Add(fixedwing);
        }

        private static string GetTypeFixedWings(int plainType)
        {
            if (plainType == 1)
            {
                return "CAG";
            }

            if (plainType == 2)
            {
                return "LGR";
            }

            if (plainType == 3)
            {
                return "PRV";
            }

            return "Unknown";
        }

        private static string GetStatus(bool status)
        {
            if (status == true)
            {
                return "Working";
            }

            return "Out";
        }
    }
}
